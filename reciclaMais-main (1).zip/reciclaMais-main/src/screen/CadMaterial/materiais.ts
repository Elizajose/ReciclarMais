
let materiais = [
  'Aluminio',
  'Cobre',
  'Ferro',
  'Papelão',
  'Plástico',
  'Vidro',

]

export default materiais;