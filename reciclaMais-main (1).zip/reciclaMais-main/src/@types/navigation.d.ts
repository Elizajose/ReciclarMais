export declare global{
    namespace ReactNavigation{
        interface RootParamList{
            Login: undefined,
            Registro: undefined,
            AdmHome: undefined,
            UserHome: undefined,
            Home: object
        }
    }
}